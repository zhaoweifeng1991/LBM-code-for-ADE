A=load("1D_T=1000grid_200.txt");
B=load("分叉图.txt");
x=A(:,1);
y=A(:,2);
x3=B(:,1);
y3=B(:,2);
x1=x(1:55);
y1=zeros(size(x1));
plot(x,y,'r','LineWidth',1);hold on;
plot(x1,y1,'--r','LineWidth',1);hold on;
plot(x3,y3,'o');hold on;
grid on;

set(gca,'FontSize',16); 
xlabel("$\sigma$",'interpreter','latex','FontSize',20);
ylabel('$<x>$','interpreter','latex','FontSize',20);
xlim([-0.05,1]);
ylim([-0.05,1]);
legend('Stable branch','Unstable branch','Reference branch from [6]')
