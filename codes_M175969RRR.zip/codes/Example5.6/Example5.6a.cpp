#include<iostream> 
#include<cmath> 
#include<cstdlib> 
#include<iomanip> 
#include<fstream> 
#include<sstream> 
#include<string> 
#include<vector>
#include<stdio.h> 
#include<conio.h> 

using namespace std;

const int Q = 3;
const int NX = 199;

int e[Q] = { 0,1,-1 };
double w[Q] = { 2.0 / 3,1.0 / 6,1.0 / 6 };
vector<double>  u0(NX + 1), u(NX + 1);
double f[NX + 1][Q], ff[NX + 1][Q], F[NX + 1][Q], xlabel[NX + 1];
int i, k, ip, n, l, ic;
double c, dx, Lx, dt, tau, p, mu, v, ep, sigma,sum_u, total, total_1, total_2;

double pi = 3.1415926;

void init();
double feq(int k, double u_temp, double W1);
double W_1(int i);
void evolution();


int main()
{
	
	{
		double sigma = 0.1; //0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0
		init();
		double T = 1000;
		double NSTEP = T / dt;
		for (n = 0; n < NSTEP; n++)
		{
			evolution();
		}
		{
			ostringstream name; 
            name<<"T=1000"<<" "<<"grid<<"_"<<NX<<" "<<"sigma"<<"_"<<sigma<<".txt"; 
            ofstream out(name.str().c_str()); 
			for (i = 0; i <= NX; i++)
			{
				out << xlabel[i] << " " << u[i] << "\n";
			}
		}
	}
	return 0;
}

void init()
{
	Lx = 5.0;
	dx = Lx / (NX + 1);
	dt = dx * dx;


	c = dx / dt;

	for (i = 0; i <= NX; i++)
	{
		xlabel[i] = i * dx + 0.5 * dx - Lx / 2;
	}
	for (i = 0; i <= NX; i++)
	{
		u[i] = 1 / sqrt(2 * pi) * exp(-(xlabel[i] - 0.5) * (xlabel[i] - 0.5) / 2);
	}
	for (i = 0; i <= NX; i++)
	{
		for (k = 0; k < Q; k++)
		{
			f[i][k] = feq(k, u[i], W_1(i));
		}
	}
}

double W_1(int i)
{
	double W_1;
	W_1 = 0;
	for (ic = 0; ic <= NX; ic++)
	{
		W_1 += -(xlabel[i] - xlabel[ic]) * u[ic] * dx;
	}
	W_1 += xlabel[i] - xlabel[i] * xlabel[i] * xlabel[i];
	return W_1;
}

double feq(int k, double u_temp, double W1)
{
	double feq;

	feq = w[k] * u_temp + w[k] * (c * e[k] * u_temp * W1) / (c * c / 3.0);

	return feq;
}

void evolution()
{

	for (i = 0; i <= NX; i++)
	{

		v = sigma;

		for (k = 0; k < Q; k++)
		{
			F[i][k] = f[i][k] + (1.0 / (3 * v + 0.5)) * (feq(k, u[i], W_1(i)) - f[i][k]);
		}
	}



	for (i = 0; i <= NX; i++)
	{
		for (k = 0; k < Q; k++)
		{
			ip = i - e[k];
			ff[i][k] = F[(ip + NX + 1) % (NX + 1)][k];
		}
	}


	for (i = 0; i <= NX; i++)
	{
		u[i] = 0.0;

		for (k = 0; k < Q; k++)
		{

			f[i][k] = ff[i][k];
			u[i] += f[i][k];

		}
	}

}