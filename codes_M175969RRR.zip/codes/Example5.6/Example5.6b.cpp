#include<iostream> 
#include<cmath> 
#include<cstdlib> 
#include<iomanip> 
#include<fstream> 
#include<sstream> 
#include<string> 
#include<vector>
#include<stdio.h> 
#include<conio.h> 

using namespace std;

const int Q = 3;
const int NX = 199;

int e[Q] = { 0,1,-1 };
double w[Q] = { 2.0 / 3,1.0 / 6,1.0 / 6 };
vector<double>  u0(NX + 1), u(NX + 1);
double f[NX + 1][Q], ff[NX + 1][Q], F[NX + 1][Q], xlabel[NX + 1];
int i, k, ip, n, l, ic;
double c, dx, Lx, dt, tau, p, mu, v, ep, sigma,sum_u, total, total_1, total_2;

double pi = 3.1415926;

void init();
double feq(int k, double u_temp, double W1);
double W_1(int i);
void evolution();


int main()
{

	
	double T = 1000;
	
	sigma = 0.001;
	while(sigma<=0.01)
	{
		init();
		double NSTEP = T / dt;
		for (n = 0; n < NSTEP; n++)
		{
			if (n % 1000 == 0)
			{
				u0 = u;
			}


			evolution();

			if ((n + 1) % 1000 == 0)
			{
				total_1 = 0;
				total_2 = 0;
				for (i = 0; i <= NX; i++)
				{
					total_1 += (u0[i] - u[i]) * (u0[i] - u[i]);
					total_2 += u[i] * u[i];
				}
				total = total_1 / total_2;

				if (total < 1e-10)
					break;
			}
		}
		{
			sum_u = 0;
			for (i = 0; i <= NX; i++)
			{
				sum_u += xlabel[i] * u[i] * dx;
			}
			ofstream outFile("1D_T=1000grid_1000.txt", std::ios::app);
			outFile << sigma << " " << sum_u << "\n";
		}
		sigma += 0.001;
	}
	return 0;
}

void init()
{
	Lx = 5.0;
	dx = Lx / (NX + 1);
	dt = dx * dx;


	c = dx / dt;

	for (i = 0; i <= NX; i++)
	{
		xlabel[i] = i * dx + 0.5 * dx - Lx / 2;
	}
	for (i = 0; i <= NX; i++)
	{
		u[i] = 1 / sqrt(2 * pi) * exp(-(xlabel[i] - 0.5) * (xlabel[i] - 0.5) / 2);
	}
	for (i = 0; i <= NX; i++)
	{
		for (k = 0; k < Q; k++)
		{
			f[i][k] = feq(k, u[i], W_1(i));
		}
	}
}

double W_1(int i)
{
	double W_1;
	W_1 = 0;
	for (ic = 0; ic <= NX; ic++)
	{
		W_1 += -(xlabel[i] - xlabel[ic]) * u[ic] * dx;
	}
	W_1 += xlabel[i] - xlabel[i] * xlabel[i] * xlabel[i];
	return W_1;
}

double feq(int k, double u_temp, double W1)
{
	double feq;

	feq = w[k] * u_temp + w[k] * (c * e[k] * u_temp * W1) / (c * c / 3.0);

	return feq;
}

void evolution()
{

	for (i = 0; i <= NX; i++)
	{
		//ep = 0.17;
		v = sigma;

		for (k = 0; k < Q; k++)
		{
			F[i][k] = f[i][k] + (1.0 / (3 * v + 0.5)) * (feq(k, u[i], W_1(i)) - f[i][k]);
		}
	}



	for (i = 0; i <= NX; i++)
	{
		for (k = 0; k < Q; k++)
		{
			ip = i - e[k];
			ff[i][k] = F[(ip + NX + 1) % (NX + 1)][k];
		}
	}


	for (i = 0; i <= NX; i++)
	{
		u[i] = 0.0;

		for (k = 0; k < Q; k++)
		{

			f[i][k] = ff[i][k];
			u[i] += f[i][k];

		}
	}

}