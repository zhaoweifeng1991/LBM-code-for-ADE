%num_1d_2
format long;
A=load("T=1000 grid_200 sigma_1.txt");
B=load("T=1000 grid_200 sigma_0.9.txt");
C=load("T=1000 grid_200 sigma_0.8.txt");
D=load("T=1000 grid_200 sigma_0.7.txt");
E=load("T=1000 grid_200 sigma_0.6.txt");
F=load("T=1000 grid_200 sigma_0.5.txt");
G=load("T=1000 grid_200 sigma_0.4.txt");
H=load("T=1000 grid_200 sigma_0.3.txt");
I=load("T=1000 grid_200 sigma_0.2.txt");
J=load("T=1000 grid_200 sigma_0.1.txt");
x=A(:,1);
y1=A(:,2); z1=sum(x.*y1/20);
y2=B(:,2); z2=sum(x.*y2/20);
y3=C(:,2); z3=sum(x.*y3/20);
y4=D(:,2);z4=sum(x.*y4/20);
y5=E(:,2);z5=sum(x.*y5/20);
y6=F(:,2);z6=sum(x.*y6/20);
x1=G(:,1);
y7=G(:,2);z7=sum(x1.*y7/40);
y8=H(:,2);z8=sum(x1.*y8/40);
y9=I(:,2);z9=sum(x1.*y9/40);
y10=J(:,2);z10=sum(x1.*y10/40);

%u=[1 0.9 0.8 0.7 0.6 0.5 0.4 0.3 0.2 0.1];
%v=[z1 z2 z3 z4 z5 z6 z7 z8 z9 z10];
%plot(u,v);

plot(x,y1,'LineWidth',1.5);hold on;
plot(x,y2,'LineWidth',1.5);hold on;
plot(x,y3,'LineWidth',1.5);hold on;
plot(x,y4,'LineWidth',1.5);hold on;
plot(x,y5,'LineWidth',1.5);hold on;
plot(x,y6,'LineWidth',1.5);hold on;
plot(x1,y7,'LineWidth',1.5);hold on;
plot(x1,y8,'LineWidth',1.5);hold on;
plot(x1,y9,'LineWidth',1.5);hold on;
plot(x1,y10,'LineWidth',1.5);hold on;
 
set(gca,'FontSize',16); 


xlabel('$x$','interpreter','latex','FontSize',20);
ylabel('$\rho$','interpreter','latex','FontSize',20);
xlim([-2.8,2.8]);
ylim([-0.1,2.1]);
legend({'\sigma=1','\sigma=0.9','\sigma=0.8','\sigma=0.7','\sigma=0.6','\sigma=0.5','\sigma=0.4','\sigma=0.3','\sigma=0.2','\sigma=0.1'});
lgd=legend({'\sigma=1','\sigma=0.9','\sigma=0.8','\sigma=0.7','\sigma=0.6','\sigma=0.5','\sigma=0.4','\sigma=0.3','\sigma=0.2','\sigma=0.1'});
lgd.FontSize=10;
grid on;
