
NX=80;
NY=80;

A=load("N2D_T = 0grid80_80迭代_0.txt");
B=load("N2D_T = 2grid80_80迭代_200.txt");
C=load("N2D_T = 4grid80_80迭代_400.txt");
D=load("N2D_T = 6grid80_80迭代_600.txt");
E=load("N2D_T = 10grid80_80迭代_1000.txt");
F=load("N2D_T = 15grid80_80迭代_1500.txt");
%G=load("N2D_T = 7grid80_80迭代_7000.txt");
%H=load("N2D_T = 8grid80_80迭代_8000.txt");
%I=load("N2D_T = 9grid80_80迭代_9000.txt");
%J=load("N2D_T = 10grid80_80迭代_10000.txt");
x=reshape(A(:,1),NX,NY);
y=reshape(A(:,2),NX,NY);
u1=reshape(A(:,3),NX,NY);
u2=reshape(B(:,3),NX,NY);
u3=reshape(C(:,3),NX,NY);
u4=reshape(D(:,3),NX,NY);
u5=reshape(E(:,3),NX,NY);
u6=reshape(F(:,3),NX,NY);
% u7=reshape(G(:,3),NX,NY);
%u8=reshape(H(:,3),NX,NY);
%u9=reshape(I(:,3),NX,NY);
%u10=reshape(J(:,3),NX,NY);

subplot(2,3,1);
surf(x,y,u1,'FaceColor', 'interp', 'LineWidth', 1.5);  % 绘制曲面并进行颜色插值  
shading interp;
axis([-4 4 -4 4 -0.001 1]);
title("$t=0$",'interpreter','latex');
xlabel("$y$",'interpreter','latex','FontSize',16);
ylabel("$x$",'interpreter','latex','FontSize',16);
zlabel('$\rho$','interpreter','latex','FontSize',16);

subplot(2,3,2);
surf(x,y,u2);
shading interp;
axis([-4 4 -4 4 -0.03 1.5 ]);
title("$t=2$",'interpreter','latex');
xlabel("$y$",'interpreter','latex','FontSize',16);
ylabel("$x$",'interpreter','latex','FontSize',16);
zlabel('$\rho$','interpreter','latex','FontSize',16);

subplot(2,3,3);
surf(x,y,u3);
shading interp;
axis([-4 4 -4 4 -0.03 1.5 ]);
title("$t=4$",'interpreter','latex');
xlabel("$y$",'interpreter','latex','FontSize',16);
ylabel("$x$",'interpreter','latex','FontSize',16);
zlabel('$\rho$','interpreter','latex','FontSize',16);

subplot(2,3,4);
surf(x,y,u4);
shading interp;
axis([-4 4 -4 4 -0.03 1.5]);
title("$t=6$",'interpreter','latex');
xlabel("$y$",'interpreter','latex','FontSize',16);
ylabel("$x$",'interpreter','latex','FontSize',16);
zlabel('$\rho$','interpreter','latex','FontSize',16);

subplot(2,3,5);
surf(x,y,u5);
shading interp;
axis([-4 4 -4 4 -0.03 1.5]);
title("$t=10$",'interpreter','latex');
xlabel("$y$",'interpreter','latex','FontSize',16);
ylabel("$x$",'interpreter','latex','FontSize',16);
zlabel('$\rho$','interpreter','latex','FontSize',16);

subplot(2,3,6);
surf(x,y,u6);
shading interp;
axis([-4 4 -4 4 -0.05 3]);
title("$t=15$",'interpreter','latex');
xlabel("$y$",'interpreter','latex','FontSize',16);
ylabel("$x$",'interpreter','latex','FontSize',16);
zlabel('$\rho$','interpreter','latex','FontSize',16);
 
% subplot(5,2,7);
% surf(x,y,u7);
% axis([-4 4 -4 4 ]);
% title("T=7");
% xlabel("x");
% ylabel("y");
% zlabel('$\rho$','interpreter','latex');
% 
% subplot(5,2,8);
% surf(x,y,u8);
% axis([-4 4 -4 4 ]);
% title("T=8");
% xlabel("x");
% ylabel("y");
% zlabel('$\rho$','interpreter','latex');
% 
% subplot(5,2,9);
% surf(x,y,u6);
% axis([-4 4 -4 4 ]);
% title("T=9");
% xlabel("x");
% ylabel("y");
% zlabel('$\rho$','interpreter','latex');
% 
% subplot(5,2,10);
% surf(x,y,u10);
% axis([-4 4 -4 4 ]);
% title("T=10");
% xlabel("x");
% ylabel("y");
% zlabel('$\rho$','interpreter','latex');



