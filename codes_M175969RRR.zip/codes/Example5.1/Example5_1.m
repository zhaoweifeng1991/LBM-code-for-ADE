
%常系数误差
e1=[
0.010761179
0.0027148015
0.00068026069
0.00017017045
0.00004255663
];

%变系数误差
e2=[
0.0058866052
0.0014641661
0.00036561918
9.1384846e-05
2.2850915e-05
];

n=[
20
40
80
160
320
];


f1=figure(1);
plot(log10(1./n),log10(e1),'rd-','LineWidth',2,'MarkerSize',10); hold on;
plot(log10(1./n),log10(e2),'bv-','LineWidth',2,'MarkerSize',10); hold on;

p1=polyfit(log10(n),log10(e1),1)
p2=polyfit(log10(n),log10(e2),1)

%f1 = polyval(p1,log10(n))

x1=linspace(-2.5,-1.3,100);
y1=2*x1+0.5;
plot(x1,y1,'k--','LineWidth',2); 

xlabel('$\log_{10}h$','interpreter','latex', 'FontSize',18);
ylabel('$\log_{10}E_r$','interpreter','latex', 'FontSize',18);
axis([-2.6 -1.2 -5 -1.5]); % 设置坐标轴在指定的区间

set(gca,'FontSize',14);   %设定刻度字体大小
set(gca, 'XTick',[-2.6,-1.9,-1.2] );         % X轴的记号点 
set(gca, 'YTick',[-5,-3.5,-2] );         % Y轴的记号点
%set(gca,'YMinorTick','off','XMinorTick','off');

legend({'$\nu=0.1$','$\nu=0.1(1+\rho^2)$','\mbox{Slope}=2'},...
   'FontSize',16,'interpreter','latex','Box','off','EdgeColor','w','position',[0.24,0.77,0.1,0.1]);
%annotation(f1,'textbox',...
   % [0.43 0.826190476190476 0.0632857142857143 0.0333333333333358],...
   % 'String',{'$${s_{\nu}}=0.9$$'},'FontSize',18,'interpreter','latex','EdgeColor','w',...
   % 'FitBoxToText','off');

