#include<iostream> 
#include<cmath> 
#include<cstdlib> 
#include<iomanip> 
#include<fstream> 
#include<sstream> 
#include<string> 
#include<stdio.h> 
#include<conio.h> 
#include <chrono>  
#include <thread>


using namespace std;

const int Q=3; 
const int NX=159; 
const int NSTEP=(NX+1)*(NX+1)/10;

int e[Q] = { 0,1,-1};                                                      
double w[Q] = { 2.0 / 3,1.0 / 6,1.0 / 6 };
double u[NX+1],u0[NX+1],f[NX+1][Q],ff[NX+1][Q],F[NX+1][Q],xlabel[NX+1]; 
int i,k,ip,n,l,ic; 
double c,dx,Lx,dt,tau,error; 

double alpha;
double pi=3.1415926;

void init(); 
double feq(int k,double u_temp,double W1 ); 
double W_1(int i);
double W_2(int i);
void evolution(); 
void Error();


int main()
{
    using namespace std;

    init();

    for(n=0;n<NSTEP;n++)
    {
        evolution();
    }
    Error();
	  cout<< setprecision(8) <<"The relative error of u is: " <<error<<endl;
    cout<<"The number of grids is: " << NX+1 <<endl;
    return 0;
}

void init() 
{ 
  Lx=1.0; 
  dx=Lx/(NX+1); 
  
  dt = dx * dx;
  c=dx/dt;
 


  for(i=0;i<=NX;i++)    
  {
	  xlabel[i]=i*dx + 0.5*dx;
  }

  for(i=0;i<=NX;i++)    
    { 
      u[i] =sin(2.0*pi*xlabel[i]);
    }

  for(i=0;i<=NX;i++)    
  {
    for(k=0;k<Q;k++) 
      { 
        f[i][k]=feq(k,u[i],W_1(i)); 
      }
  }
}

double W_1(int i)
{
  double W_1;
  W_1 = 0;
  for(ic=0;ic<=NX;ic++)
  {
  W_1 +=  sin(2*pi*(xlabel[i]-xlabel[ic]))*u[ic]*dx;
  }
  return W_1;
}

double W_2(int i)
{
  double W_2;
  W_2 = 0;
  for(ic=0;ic<=NX;ic++)
  {
  W_2 +=  cos(2*pi*(xlabel[i]-xlabel[ic]))*u[ic]*dx;
  }
  return W_2;
}


double feq(int k,double u_temp,double W1)   
{ 
  double feq;

         feq = w[k]*u_temp +  w[k]* (c*e[k]*u_temp*W1)/(c*c/3.0);		
		
  return feq; 
}

void evolution() 
{ 
    // 常扩散系数alpha=0.1
	 for(i=0;i<=NX;i++) 
		{
      alpha=0.1;
      tau=3*alpha+0.5;
			for(k=0;k<Q;k++) 
			{		      
				F[i][k] = f[i][k] + (1.0/tau) * (feq(k, u[i],W_1(i)) - f[i][k])
						   + dt*w[k]*(sin(2.0*pi*xlabel[i])
							           + 2.0*pi*(n*dt+1)*cos(2.0*pi*xlabel[i])*W_1(i)+2.0*pi*u[i]*W_2(i)
									      + alpha*4.0*pi*pi*(n*dt+1)*sin(2.0*pi*xlabel[i])		
                                       );     		                    			      
			}
		}

    // 变系数扩散系数alpha=0.1*(1+rho^2)
    /*
	 for(i=0;i<=NX;i++) 
		{
      alpha=0.1*(1+u[i]*u[i]);
      tau=3*alpha+0.5;
			for(k=0;k<Q;k++) 
			{		      
				F[i][k] = f[i][k] + (1.0/tau) * (feq(k, u[i],W_1(i)) - f[i][k])
						   + dt*w[k]*(sin(2.0*pi*xlabel[i])
							           + 2.0*pi*(n*dt+1)*cos(2.0*pi*xlabel[i])*W_1(i)+2.0*pi*u[i]*W_2(i)
									      + alpha*4.0*pi*pi*(n*dt+1)*sin(2.0*pi*xlabel[i])
                        -0.8*pi*pi*(n*dt+1)*cos(2.0*pi*xlabel[i])*(n*dt+1)*cos(2.0*pi*xlabel[i])		
                                       );     		                    			      
			}
		}	
    */
	
	for(i=0;i<=NX;i++)         
		{
			
			for(k=0;k<Q;k++) 
			{
				ip=i-e[k]; 
				ff[i][k] = F[(ip+NX+1)%(NX+1)][k];
			}			
		}


	for(i=0;i<=NX;i++)         
			{
                u[i]= 0.0;
			 
				for(k=0; k<Q; k++) 
				{    
			
					f[i][k] = ff[i][k];
					u[i]+=f[i][k];
				}
		
			}

}

		void Error()   
        { 
          double temp1,temp2; 
          temp1=0; 
          temp2=0; 
          for(i=0;i<=NX;i++) 
            { 
				
                  u0[i] =(n*dt+1)*sin(2.0*pi*xlabel[i]);

                  temp1+=(u[i]-u0[i])*(u[i]-u0[i]) ; 
                  temp2+=u0[i]*u0[i]; 		      
		
			}

            temp1=sqrt(temp1); 
            temp2=sqrt(temp2); 
            error=temp1/(temp2+1e-30); 
         }