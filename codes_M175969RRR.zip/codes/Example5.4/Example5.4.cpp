#include<iostream> 
#include<cmath> 
#include<cstdlib> 
#include<iomanip> 
#include<fstream> 
#include<sstream> 
#include<string> 
#include<stdio.h> 
#include<conio.h> 

using namespace std;

const int Q = 3;
const int NX = 119;

int e[Q] = { 0,1,-1 };
double w[Q] = { 2.0 / 3,1.0 / 6,1.0 / 6 };
double u[NX + 1], u0[NX + 1], f[NX + 1][Q], ff[NX + 1][Q], F[NX + 1][Q], xlabel[NX + 1];
int i, k, ip, n, l, ic;
double c, dx, Lx, dt, tau, p, mu, v, ep;

double pi = 3.1415926;

void init();
double feq(int k, double u_temp, double W1);
double W_1(int i);
void evolution();


int main()
{

	init();
	int T = 600;

	double NSTEP = T / dt;
	for (n = 0; n < NSTEP; n++)
	{

		evolution();
		if ((n + 1) %(10 * 100 * 2)==0)

		{
			ofstream outFile("1D_T=600 grid_120 ep_0.001_2.txt", std::ios::app);
			for (i = 0; i <= NX; i++)
			{
				outFile << xlabel[i] << " " << u[i] << " " << dt * (n + 1) << "\n";
			}
		}


	}
	return 0;
}

void init()
{
	Lx = 12.0;
	dx = Lx / (NX + 1);
	//mu = 0.05;
	dt = dx * dx;
	//mu = dt / (dx * dx);

	c = dx / dt;

	for (i = 0; i <= NX; i++)
	{
		xlabel[i] = i * dx + 0.5 * dx - Lx / 2;
	}
	for (i = 0; i <= NX; i++)
	{
		//u[i] = 1/sqrt(2*pi)*exp(-xlabel[i]*xlabel[i]/2);
		u[i] = 1 / (2 * sqrt(2 * pi)) * (exp(-(xlabel[i] - 2.5) * (xlabel[i] - 2.5) / 2) + exp(-(xlabel[i] + 2.5) * (xlabel[i] + 2.5) / 2));

	}

	ofstream outFile("1D_T=600 grid_120 ep_0.001_2.txt", std::ios::app);
	for (i = 0; i <= NX; i++)
	{
		outFile << xlabel[i] << " " << u[i] << " " << 0  << "\n";
	}

	for (i = 0; i <= NX; i++)
	{
		for (k = 0; k < Q; k++)
		{
			f[i][k] = feq(k, u[i], W_1(i));
		}
	}
}

double W_1(int i)
{
	double W_1;
	W_1 = 0;
	for (ic = 0; ic <= NX; ic++)
	{
		W_1 += -1 / sqrt(2 * pi) * (xlabel[i] - xlabel[ic]) * exp(-(xlabel[i] - xlabel[ic]) * (xlabel[i] - xlabel[ic]) / 2) * u[ic] * dx;
	}
	return W_1;
}



double feq(int k, double u_temp, double W1)
{
	double feq;

	feq = w[k] * u_temp + w[k] * (c * e[k] * u_temp * W1) / (c * c / 3.0);

	return feq;
}

void evolution()
{

	for (i = 0; i <= NX; i++)
	{
		ep = 0.001; //0.002
		v = 0.5 * 0.28 * sqrt(u[i]) + ep;//2*1.48*u[i]*u[i] + ep

		for (k = 0; k < Q; k++)
		{
			F[i][k] = f[i][k] + (1.0 / (3 * v + 0.5)) * (feq(k, u[i], W_1(i)) - f[i][k]) - w[k] * ep * (u[(i + 1) % (NX + 1)] - 2 * u[i] + u[(i - 1 + NX + 1) % (NX + 1)]);
		}
	}



	for (i = 0; i <= NX; i++)
	{
		for (k = 0; k < Q; k++)
		{
			ip = i - e[k];
			ff[i][k] = F[(ip + NX + 1) % (NX + 1)][k];
		}
	}


	for (i = 0; i <= NX; i++)
	{
		u[i] = 0.0;

		for (k = 0; k < Q; k++)
		{

			f[i][k] = ff[i][k];
			u[i] += f[i][k];

		}

		//if (u[i] < 0)
		//	u[i] = 0;
	}

}