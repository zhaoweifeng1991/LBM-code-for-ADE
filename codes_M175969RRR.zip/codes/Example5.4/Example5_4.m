%test3.eps ep=0.001
%test4.eps ep=0.002
NX=120;
NY=31;
A=load("1D_T=600 grid_120 ep_0.001_2.txt");
x=A(:,1);
y=A(:,3);
z=A(:,2);


X=reshape(A(:,1),NX,NY);
Y=reshape(A(:,3),NX,NY);
Z=reshape(A(:,2),NX,NY);
%figure;
%scatter3(x,y,z);
%mesh(X,Y,Z);

figure;
plot3(X(:,1), Y(:,1), Z(:,1), 'k'); % 绘制第一个时间点的曲线
hold on;
for i = 2:NY
    plot3(X(:,i), Y(:,i), Z(:,i), 'k');
end
hold off;

grid on;


xlim([-6,6]);
zlim([-0.01,0.8]);
xlabel('x');
ylabel('t');
zlabel('\rho');



