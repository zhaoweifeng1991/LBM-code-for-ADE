%num_2d_1.eps
NX=80;
NY=80;

A=load("2D_T = 2 80_80迭代_200.txt");

x=reshape(A(:,1),NX,NY);
y=reshape(A(:,2),NX,NY);
u1=reshape(A(:,3),NX,NY);


surf(x,y,u1,'FaceColor', 'interp');  % 绘制曲面并进行颜色插值  
shading interp;
axis([-4.1 4.1 -4.1 4.1 -0.01 0.16]);

set(gca,'FontSize',16); 

xticks(-4:2:4);
yticks(-4:2:4);
zticks(0:0.02:0.14);

xlabel("$x$",'interpreter','latex','FontSize',20);
ylabel("$y$",'interpreter','latex','FontSize',20);
zlabel('$\rho$','interpreter','latex','FontSize',20);

grid on;