
NX=160;
NY=160;
A=load("T= 4grid160.txt");
B=load("参考数据.txt");
x=reshape(A(:,1),1,NX);
y=reshape(A(:,2),1,NX);
x1=B(:,1);
y1=B(:,2);
plot(x,y,'LineWidth',1.5);hold on;
plot(x1,y1,'o','MarkerSize', 5);
 
set(gca,'FontSize',16); 
xlabel("$x$",'interpreter','latex','FontSize',20);
ylabel('$\rho$','interpreter','latex','FontSize',20);
xlim([-4.4,4.4]);
ylim([-0.02,0.48]);

legend('LBM solutions','Reference solutions from [6]');
lgd=legend('LBM solution','Reference solution from [6]');
lgd.FontSize=12;
grid on;
