#include<iostream> 
#include<cmath> 
#include<cstdlib> 
#include<iomanip> 
#include<fstream> 
#include<sstream> 
#include<string> 
#include<stdio.h> 
#include<conio.h> 

using namespace std;

const int Q=3; 
const int NX=199; 

int e[Q] = { 0,1,-1};                                                      
double w[Q] = { 2.0 / 3,1.0 / 6,1.0 / 6 };
double u[NX+1],u0[NX+1],f[NX+1][Q],ff[NX+1][Q],F[NX+1][Q],xlabel[NX+1]; 
int i,k,ip,n,l,ic; 
double c,dx,Lx,dt,tau,p,mu,v; 

double pi=3.1415926;

void init(); 
double feq(int k,double u_temp,double W1); 
double W_1(int i);
void evolution(); 


int main()
{

    init();
    int T=4;
    double NSTEP = T/dt;
	for (n = 0; n < NSTEP; n++)
	{
		evolution();	
	}
				{
				ofstream outFile("T=4grid160.txt", std::ios::app);
				for (i = 0; i <= NX; i++)
				{
				outFile << xlabel[i] << " " << u[i]  << "\n";
				}
			}
    return 0;
}

void init() 
{ 
  Lx=8.0; 
  dx=Lx/(NX+1); 
  dt = dx*dx;
  //mu = dt / (dx * dx);
 
  c=dx/dt;

  for(i=0;i<=NX;i++)    
  {
	  xlabel[i]=i*dx + 0.5*dx -4.0;
  }
  for(i=0;i<=NX;i++)    
    { 
	  u[i] = 1/8.0;
    }
  for(i=0;i<=NX;i++)    
  {
    for(k=0;k<Q;k++) 
      { 
        f[i][k]=feq(k,u[i],W_1(i)); 
      }
  }
}
/*double G(double p)
{
	if (p >= -0.5 && p <= 0.5)
		return -0.5 * sin(pi * p);
	else
		return 0;
}*/
double W_1(int i)
{
	double W_1;
	W_1 = 0;
	for (ic = 0; ic <= NX; ic++)
		{
			W_1 += -(xlabel[i] - xlabel[ic]) * u[ic]  * dx;
		}
	return W_1;
}



double feq(int k,double u_temp,double W1)   
{ 
  double feq;

         feq = w[k]*u_temp +  w[k]* (  c*e[k]*u_temp*W1 )/(c*c/3.0);		
		
  return feq; 
}

void evolution() 
{ 

	 for(i=0;i<=NX;i++) 
		{
			v = 1;

			for(k=0;k<Q;k++) 
			{		      
				F[i][k] = f[i][k] + (1.0 / (3 * v + 0.5)) * (feq(k, u[i], W_1(i)) - f[i][k]);
			}
		}
	
	
	
	for(i=0;i<=NX;i++)         
		{		
			for(k=0;k<Q;k++) 
			{
				ip=i-e[k]; 
				ff[i][k] = F[(ip+NX+1)%(NX+1)][k];
			}			
		}


	for(i=0;i<=NX;i++)         
			{
                u[i]= 0.0;
			 
				for(k=0; k<Q; k++) 
				{    
			
					f[i][k] = ff[i][k];
					u[i]+=f[i][k];
					
				}
			}

}		