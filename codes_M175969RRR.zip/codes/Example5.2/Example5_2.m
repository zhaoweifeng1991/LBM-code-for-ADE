
%��ϵ�����
e1=[
0.01916173086
0.00479374814
0.00213086736
0.0011986816
0.00076718076
];
%��ϵ�����
e2=[
0.021175949
0.0053354676
0.0023746872
0.0013364302
0.00085551898
];

n=[
20
40
60
80
100
];


f1=figure(1);
plot(log10(1./n),log10(e1),'rd-','LineWidth',2,'MarkerSize',10); hold on;
plot(log10(1./n),log10(e2),'bv-','LineWidth',2,'MarkerSize',10); hold on;

p1=polyfit(log10(n),log10(e1),1)
p2=polyfit(log10(n),log10(e2),1)

%f1 = polyval(p1,log10(n))

x1=linspace(-2,-1.3,100);
y1=2*x1+0.5;
plot(x1,y1,'k--','LineWidth',2); 

xlabel('$\log_{10}h$','interpreter','latex', 'FontSize',18);
ylabel('$\log_{10}E_r$','interpreter','latex', 'FontSize',18);
axis([-2.1 -1.2 -3.5 -1.5]); % ������������ָ��������

set(gca,'FontSize',14);   %�趨�̶������С
set(gca, 'XTick',[-2,-1.6,-1.2] );         % X��ļǺŵ� 
set(gca, 'YTick',[-3.5,-2.5,-1.5] );         % Y��ļǺŵ�
%set(gca,'YMinorTick','off','XMinorTick','off');

legend({'$\nu=0.1$','$\nu=0.1(1+\rho^2)$','\mbox{Slope}=2'},...
   'FontSize',16,'interpreter','latex','Box','off','EdgeColor','w','position',[0.24,0.77,0.1,0.1]);
%annotation(f1,'textbox',...
   % [0.43 0.826190476190476 0.0632857142857143 0.0333333333333358],...
   % 'String',{'$${s_{\nu}}=0.9$$'},'FontSize',18,'interpreter','latex','EdgeColor','w',...
   % 'FitBoxToText','off');

