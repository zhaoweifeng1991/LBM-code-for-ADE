#include<iostream> 
#include<cmath> 
#include<cstdlib> 
#include<iomanip> 
#include<fstream> 
#include<sstream> 
#include<string> 
#include<stdio.h> 
#include<conio.h> 
#include <chrono>  
#include <thread>


using namespace std;

const int Q=5; 
const int NX=19; // NX=19,39,59,79,99
const int NY=19;
const int NSTEP=(NX+1)*(NX+1)/10; // T=dt*NSTEP=0.1

int e[Q][2] = { {0,0},{1,0},{0,1},{-1,0},{0,-1}};       
int ne[Q] = { 0,3,4,1,2 };                                                
double w[Q] = { 1.0 / 3,1.0 / 6,1.0 / 6,1.0 / 6,1.0 / 6 };
double u[NX+1][NY+1],u0[NX+1][NY+1],f[NX+1][NY+1][Q],ff[NX+1][NY+1][Q],F[NX+1][NY+1][Q],xlabel[NX+1][NY+1],ylabel[NX+1][NY+1]; 
int i,j,k,ip,jp,n,l,ic,jc; 
double c,dx,dy,Lx,Ly,s_nu,D,dt,tau,niu,error; 

double alpha;
double pi=3.1415926;

void init(); 
double feq(int k,double u_temp,double W1 ,double W2); 
double W_1(int i,int j);
double W_2(int i,int j);
void evolution(); 
void Error();


int main()
{
    using namespace std;
    auto start = chrono::high_resolution_clock::now(); 
    init();

    for(n=0;n<NSTEP;n++)
    {
        evolution();
    }
    Error();
	  cout<< setprecision(8) <<"The relative error of u is: " <<error<<endl;
    cout<<"The number of grids is: " << NX+1 <<endl;
    auto end = chrono::high_resolution_clock::now();
    chrono::duration<double> duration = end - start;
	  cout << "Time cost: " << duration.count() << "s\n" ;

    return 0;
}

void init() 
{ 
  Lx=1.0; 
  Ly=1.0; 
  dx=Lx/(NX+1); 
  dy=dx; 
  dt = dx * dx;
  c=dx/dt;



  for(i=0;i<=NX;i++)    
  for(j=0;j<=NY;j++) 
  {
	  xlabel[i][j]=i*dx + 0.5*dx;
	  ylabel[i][j]=j*dy + 0.5*dy;
  }

  for(i=0;i<=NX;i++)    
    for(j=0;j<=NY;j++) 
    { 
      u[i][j] =sin(2.0*pi*xlabel[i][j])*cos(2.0*pi*ylabel[i][j]);
    }

  for(i=0;i<=NX;i++)    
  for(j=0;j<=NY;j++)
  {
    for(k=0;k<Q;k++) 
      { 
        f[i][j][k]=feq(k,u[i][j],W_1(i,j),W_2(i,j)); 
      }
  }
}

double W_1(int i,int j)
{
  double W_1;
  W_1 = 0;
  for(ic=0;ic<=NX;ic++)
  for(jc=0;jc<=NY;jc++)
  {
  W_1 +=  sin(2*pi*(xlabel[i][j]-xlabel[ic][jc]-(ylabel[i][j]-ylabel[ic][jc])))*u[ic][jc]*dx*dx;
  }
  return W_1;
}

double W_2(int i,int j)
{
  double W_2;
  W_2 = 0;
  for(ic=0;ic<=NX;ic++)
  for(jc=0;jc<=NY;jc++)
  {
  W_2 +=  cos(2*pi*(xlabel[i][j]-xlabel[ic][jc]-(ylabel[i][j]-ylabel[ic][jc])))*u[ic][jc]*dx*dx;
  }
  return W_2;
}


double feq(int k,double u_temp,double W1,double W2)   
{ 
  double feq;

         feq = w[k]*u_temp +  w[k]* (   c*e[k][0]*u_temp*W1 + c*e[k][1]*u_temp*W2)/(c*c/3.0);		
		
  return feq; 
}

void evolution() 
{ 
   // 常扩散系数alpha=0.1
	 for(i=0;i<=NX;i++) 
		for(j=0;j<=NY;j++)  
    
		{
      alpha=0.1;
			tau=3*alpha+0.5;
			for(k=0;k<Q;k++) 
			{		      
				F[i][j][k] = f[i][j][k] + (1.0/tau) * (feq(k, u[i][j],W_1(i,j),W_2(i,j)) - f[i][j][k])
						   + dt*w[k]*(sin(2.0*pi*xlabel[i][j])*cos(2.0*pi*ylabel[i][j])
							           + 2.0*pi*(n*dt+1)*cos(2.0*pi*xlabel[i][j])*cos(2.0*pi*ylabel[i][j])*W_1(i,j)+2.0*pi*u[i][j]*W_1(i,j)
                         - 2.0*pi*(n*dt+1)*sin(2.0*pi*xlabel[i][j])*sin(2.0*pi*ylabel[i][j])*W_2(i,j)+2.0*pi*u[i][j]*W_2(i,j)
									       + alpha*8.0*pi*pi*(n*dt+1)*sin(2.0*pi*xlabel[i][j])*cos(2.0*pi*ylabel[i][j])		
                                       );     		                    			      
			}
		}
    // 变扩散系数alpha=0.1*(1+rho^2)
    /*
    for(i=0;i<=NX;i++) 
		 for(j=0;j<=NY;j++)  
     { 
      alpha=0.1*(1+u[i][j]*u[i][j]);
			tau=3*alpha+0.5;
			for(k=0;k<Q;k++) 
			{		      
				F[i][j][k] = f[i][j][k] + (1.0/tau) * (feq(k, u[i][j],W_1(i,j),W_2(i,j)) - f[i][j][k])
						   + dt*w[k]*(sin(2.0*pi*xlabel[i][j])*cos(2.0*pi*ylabel[i][j])
							           + 2.0*pi*(n*dt+1)*cos(2.0*pi*xlabel[i][j])*cos(2.0*pi*ylabel[i][j])*W_1(i,j)+2.0*pi*u[i][j]*W_1(i,j)
                         - 2.0*pi*(n*dt+1)*sin(2.0*pi*xlabel[i][j])*sin(2.0*pi*ylabel[i][j])*W_2(i,j)+2.0*pi*u[i][j]*W_2(i,j)
									       + alpha*8.0*pi*pi*(n*dt+1)*sin(2.0*pi*xlabel[i][j])*cos(2.0*pi*ylabel[i][j])		
                         - 0.8*pi*pi*u[i][j]*((n*dt+1)*cos(2.0*pi*xlabel[i][j])*cos(2.0*pi*ylabel[i][j]))*((n*dt+1)*cos(2.0*pi*xlabel[i][j])*cos(2.0*pi*ylabel[i][j]))
                         - 0.8*pi*pi*u[i][j]*((n*dt+1)*sin(2.0*pi*xlabel[i][j])*sin(2.0*pi*ylabel[i][j]))*((n*dt+1)*sin(2.0*pi*xlabel[i][j])*sin(2.0*pi*ylabel[i][j]))    		                    			      
      );     		                    			      
      }
		}
    */
    
	
	
	
	for(i=0;i<=NX;i++)         
	    for(j=0;j<=NY;j++)
		{
			
			for(k=0;k<Q;k++) 
			{
				ip=i-e[k][0]; 
				jp=j-e[k][1];
				ff[i][j][k] = F[(ip+NX+1)%(NX+1)][(jp+NY+1)%(NY+1)][k];
			}			
		}


	for(i=0;i<=NX;i++)         
	    for(j=0;j<=NY;j++)
			{
        u[i][j]= 0.0;
			 
				for(k=0; k<Q; k++) 
				{    
			
					f[i][j][k] = ff[i][j][k];
					u[i][j]+=f[i][j][k];
				}
		
			}

}

		void Error()   
        { 
          double temp1,temp2; 
          temp1=0; 
          temp2=0; 
          for(i=0;i<=NX;i++) 
            for(j=0;j<=NY;j++) 
            { 
				
                  u0[i][j] =(n*dt+1)*sin(2.0*pi*xlabel[i][j])*cos(2.0*pi*ylabel[i][j]);

                  temp1+=(u[i][j]-u0[i][j])*(u[i][j]-u0[i][j]) ; 
                  temp2+=u0[i][j]*u0[i][j]; 		      
		
			      }

            temp1=sqrt(temp1); 
            temp2=sqrt(temp2); 
            error=temp1/(temp2+1e-30); 
         }