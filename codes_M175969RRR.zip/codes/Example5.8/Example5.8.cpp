#include<iostream> 
#include<cmath> 
#include<cstdlib> 
#include<iomanip> 
#include<fstream> 
#include<sstream> 
#include<string> 
#include <chrono>  
#include <thread>


using namespace std;

const int Q = 5;
const int NX = 49;
const int NY = 49;

int e[Q][2] = { {0,0},{1,0},{0,1},{-1,0},{0,-1} };
int ne[Q] = { 0,3,4,1,2 };
double w[Q] = { 1.0 / 3,1.0 / 6,1.0 / 6,1.0 / 6,1.0 / 6 };
double u[NX + 1][NY + 1], u0[NX + 1][NY + 1], f[NX + 1][NY + 1][Q], ff[NX + 1][NY + 1][Q], F[NX + 1][NY + 1][Q], xlabel[NX + 1][NY + 1], ylabel[NX + 1][NY + 1];
int i, j, k, ip, jp, n, l, ic, jc;
double c, dx, dy, Lx, Ly, s_nu, D, dt, tau, niu, error,mu;

double alpha;
double pi = 3.1415926;

void init();
double feq(int k, double u_temp, double W1, double W2);
double W_1(int i, int j);
double W_2(int i, int j);
void evolution();


int main()
{
	using namespace std;
	init();
	int T = 2;
	double NSTEP = T/dt;
	for (n = 0; n < NSTEP; n++)
	{
		if ((n + 1) % 100 == 0)
		{
			ostringstream name;
			name << "N2D_T = " << dt * n + dt<< "grid" << NX + 1 << "_" << NY + 1 << "step_" << n + 1<< ".txt";
			ofstream out(name.str().c_str());
			for (j = 0; j <= NY; j++)
				for (i = 0; i <= NX; i++)
				{
					out << xlabel[i][j] << " " << ylabel[i][j] << " " << u[i][j] << endl;
				}
		}
		evolution();

				
	}


	return 0;
}

void init()
{
	Lx = 10.0;
	Ly = 10.0;
	dx = Lx / (NX + 1);
	dy = dx;
	dt = dx * dx;
	c = dx / dt;



	for (i = 0; i <= NX; i++)
		for (j = 0; j <= NY; j++)
		{
			xlabel[i][j] = i * dx + 0.5 * dx - Lx/2;
			ylabel[i][j] = j * dy + 0.5 * dy - Ly/2;
		}

	for (i = 0; i <= NX; i++)
		for (j = 0; j <= NY; j++)
		{
			if (-1 <= xlabel[i][j] && xlabel[i][j] <= 1 && -1 <= ylabel[i][j] && ylabel[i][j] <= 1)
				u[i][j] = 2 * (pi - 0.2);
			//u[i][j] = 9 * exp(- xlabel[i][j]* xlabel[i][j] - ylabel[i][j] * ylabel[i][j]);
		}

	ostringstream name;
	name << "N2D_T = " << 0 << "grid" << NX + 1 << "_" << NY + 1 << "step_" << 0 << ".txt";
	ofstream out(name.str().c_str());
	for (j = 0; j <= NY; j++)
		for (i = 0; i <= NX; i++)
		{
			out << xlabel[i][j] << " " << ylabel[i][j] << " " << u[i][j] << endl;
		}
	for (i = 0; i <= NX; i++)
		for (j = 0; j <= NY; j++)
		{
			for (k = 0; k < Q; k++)
			{
				f[i][j][k] = feq(k, u[i][j], W_1(i, j), W_2(i, j));
			}
		}
}

double W_1(int i, int j)
{
	double W_1;
	W_1 = 0;
	for (ic = 0; ic <= NX; ic++)
		for (jc = 0; jc <= NY; jc++)
		{
			if (i == ic or j == jc)
				continue;
			W_1 += - 1 / (2 * pi) * (xlabel[i][j] - xlabel[ic][jc]) / ((xlabel[i][j] - xlabel[ic][jc]) * (xlabel[i][j] - xlabel[ic][jc]) + (ylabel[i][j] - ylabel[ic][jc]) * (ylabel[i][j] - ylabel[ic][jc])) * u[ic][jc] * dx * dx;
		}
	return W_1;
}

double W_2(int i, int j)
{
	double W_2;
	W_2 = 0;
	for (ic = 0; ic <= NX; ic++)
		for (jc = 0; jc <= NY; jc++)

		{
			if (i == ic or j == jc)
				continue;
			W_2 += -1 / (2 * pi) * (ylabel[i][j] - ylabel[ic][jc]) / ((xlabel[i][j] - xlabel[ic][jc]) * (xlabel[i][j] - xlabel[ic][jc]) + (ylabel[i][j] - ylabel[ic][jc]) * (ylabel[i][j] - ylabel[ic][jc])) * u[ic][jc] * dx * dx;
		}
	return W_2;
}


double feq(int k, double u_temp, double W1, double W2)
{
	double feq;

	feq = w[k] * u_temp + w[k] * (c * e[k][0] * u_temp * W1 + c * e[k][1] * u_temp * W2) / (c * c / 3.0);

	return feq;
}

void evolution()
{

	for (i = 0; i <= NX; i++)
		for (j = 0; j <= NY; j++)
		{
			alpha = 1;
			tau = 3*alpha+0.5;
			for (k = 0; k < Q; k++)
			{
				F[i][j][k] = f[i][j][k] + (1.0 / tau) * (feq(k, u[i][j], W_1(i, j), W_2(i, j)) - f[i][j][k]);
			}
		}



	for (i = 0; i <= NX; i++)
		for (j = 0; j <= NY; j++)
		{

			for (k = 0; k < Q; k++)
			{
				ip = i - e[k][0];
				jp = j - e[k][1];
				ff[i][j][k] = F[(ip + NX + 1) % (NX + 1)][(jp + NY + 1) % (NY + 1)][k];
			}
		}


	for (i = 0; i <= NX; i++)
		for (j = 0; j <= NY; j++)
		{
			u[i][j] = 0.0;

			for (k = 0; k < Q; k++)
			{

				f[i][j][k] = ff[i][j][k];
				u[i][j] += f[i][j][k];
			}

		}

}

