#include<iostream> 
#include<cmath> 
#include<cstdlib> 
#include<iomanip> 
#include<fstream> 
#include<sstream> 
#include<string> 
#include <vector>
#include<stdio.h> 
#include<conio.h> 
#include <chrono>  
#include <thread>


using namespace std;

const int Q = 5;
const int NX = 99;
const int NY = 99;

int e[Q][2] = { {0,0},{1,0},{0,1},{-1,0},{0,-1} };
int ne[Q] = { 0,3,4,1,2 };
double w[Q] = { 1.0 / 3,1.0 / 6,1.0 / 6,1.0 / 6,1.0 / 6 };
vector<vector<double>>  u(NX + 1, vector<double>(NY + 1)), u0(NX + 1, vector<double>(NY + 1));
double f[NX + 1][NY + 1][Q], ff[NX + 1][NY + 1][Q], F[NX + 1][NY + 1][Q], xlabel[NX + 1][NY + 1], ylabel[NX + 1][NY + 1];
int i, j, k, ip, jp, n, l, ic, jc;
double c, dx, dy, Lx, Ly, s_nu, D, dt, tau, niu, error, mu, total, total_1, total_2;

double alpha;
double pi = 3.1415926;

void init();
double feq(int k, double u_temp, double W1, double W2);
double W_1(int i, int j);
double W_2(int i, int j);
void evolution();


int main()
{
	init();
	int T = 1000;
	double NSTEP = T / dt;
	for (n = 0; n < NSTEP; n++)
	{

		if (n % 100 == 0)
		{
			u0 = u;
		}


		evolution();

		if ((n + 1) % 100 == 0)
		{
			total_1 = 0;
			total_2 = 0;
			for (i = 0; i <= NX; i++)
				for (j = 0; j <= NY; j++)
				{
				total_1 += (u0[i][j] - u[i][j]) * (u0[i][j] - u[i][j]);
				total_2 += u[i][j] * u[i][j];
				}
			total = total_1 / total_2;

			if (total < 1e-6)
				break;
		}
	 
		if ((n + 1) % 100 == 0)
		{
			ostringstream name;
			name << "N2D_T = " << dt * (n + 1) << "grid" << NX + 1 << "_" << NY + 1 << "����_" << n + 1 << "sigma_"<< alpha << ".txt";
			ofstream out(name.str().c_str());
			for (j = 0; j <= NY; j++)
				for (i = 0; i <= NX; i++)
				{
					out << xlabel[i][j] << " " << ylabel[i][j] << " " << u[i][j] << endl;
				}
		}		
	}

	{
		ostringstream name;
		name << "N2D_T = " << dt * n  << "grid" << NX + 1 << "_" << NY + 1 << "����_" << n << "sigma_" << alpha << ".txt";
		ofstream out(name.str().c_str());
		for (j = 0; j <= NY; j++)
			for (i = 0; i <= NX; i++)
			{
				out << xlabel[i][j] << " " << ylabel[i][j] << " " << u[i][j] << endl;
			}
	}

	return 0;
}

void init()
{
	Lx = 4.0;
	Ly = 4.0;
	dx = Lx / (NX + 1);
	dy = dx;
	dt = dx * dx;
	c = dx / dt;



	for (i = 0; i <= NX; i++)
		for (j = 0; j <= NY; j++)
		{
			xlabel[i][j] = i * dx + 0.5 * dx - Lx / 2;
			ylabel[i][j] = j * dy + 0.5 * dy - Ly / 2;
		}

	for (i = 0; i <= NX; i++)
		for (j = 0; j <= NY; j++)
		{
			u[i][j] = 1 / (2 * pi) * exp(-((xlabel[i][j] - 0.5) * (xlabel[i][j] - 0.5) + ylabel[i][j] * ylabel[i][j]) / 2);
		}

	for (i = 0; i <= NX; i++)
		for (j = 0; j <= NY; j++)
		{
			for (k = 0; k < Q; k++)
			{
				f[i][j][k] = feq(k, u[i][j], W_1(i, j), W_2(i, j));
			}
		}
}

double W_1(int i, int j)
{
	double W_1;
	W_1 = 0;
	for (ic = 0; ic <= NX; ic++)
		for (jc = 0; jc <= NY; jc++)
		{
			W_1 += -(xlabel[i][j] - xlabel[ic][jc]) * u[ic][jc] * dx * dx;
		}
	W_1 += xlabel[i][j] - xlabel[i][j]*(xlabel[i][j] * xlabel[i][j] + ylabel[i][j] * ylabel[i][j]);
	return W_1;
}

double W_2(int i, int j)
{
	double W_2;
	W_2 = 0;
	for (ic = 0; ic <= NX; ic++)
		for (jc = 0; jc <= NY; jc++)
		{
			W_2 += -(ylabel[i][j] - ylabel[ic][jc]) * u[ic][jc] * dx * dx;
		}
	W_2 += ylabel[i][j] - ylabel[i][j] * (xlabel[i][j] * xlabel[i][j] + ylabel[i][j] * ylabel[i][j]);
	return W_2;
}


double feq(int k, double u_temp, double W1, double W2)
{
	double feq;

	feq = w[k] * u_temp + w[k] * (c * e[k][0] * u_temp * W1 + c * e[k][1] * u_temp * W2) / (c * c / 3.0);

	return feq;
}

void evolution()
{

	for (i = 0; i <= NX; i++)
		for (j = 0; j <= NY; j++)
		{
			alpha =0.2;
			tau = 3 * alpha + 0.5;
			for (k = 0; k < Q; k++)
			{
				F[i][j][k] = f[i][j][k] + (1.0 / tau) * (feq(k, u[i][j], W_1(i, j), W_2(i, j)) - f[i][j][k]);
			}
		}



	for (i = 0; i <= NX; i++)
		for (j = 0; j <= NY; j++)
		{

			for (k = 0; k < Q; k++)
			{
				ip = i - e[k][0];
				jp = j - e[k][1];
				ff[i][j][k] = F[(ip + NX + 1) % (NX + 1)][(jp + NY + 1) % (NY + 1)][k];
			}
		}


	for (i = 0; i <= NX; i++)
		for (j = 0; j <= NY; j++)
		{
			u[i][j] = 0.0;

			for (k = 0; k < Q; k++)
			{

				f[i][j][k] = ff[i][j][k];
				u[i][j] += f[i][j][k];
			}

		}

}

