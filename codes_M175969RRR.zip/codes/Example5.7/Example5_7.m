%num_2d_2
NX=100;
NY=100;

A=load("N2D_T = 12.48grid100_100迭代_7800sigma_0.2.txt");

x=reshape(A(:,1),NX,NY);
y=reshape(A(:,2),NX,NY);
u1=reshape(A(:,3),NX,NY);

subplot(1,2,1)
surf(x,y,u1,'FaceColor', 'interp');  % 绘制曲面并进行颜色插值 
shading interp;
axis([-2.1 2.1 -2.1 2.1 -0.001 0.8]);
xlabel("$x$",'interpreter','latex','FontSize',20);
ylabel("$y$",'interpreter','latex','FontSize',20);
zlabel('$\rho$','interpreter','latex','FontSize',20);

set(gca, 'TickLabelInterpreter', 'none');
xticks(-2:1:2);
yticks(-2:1:2);
zticks(0:0.1:0.8);
set(gca,'FontSize',12); 

grid on;

subplot(1,2,2)
contourf(x, y, u1,15);
xlabel("$x$",'interpreter','latex','FontSize',16);
ylabel("$y$",'interpreter','latex','FontSize',16);
set(gca,'FontSize',12); 